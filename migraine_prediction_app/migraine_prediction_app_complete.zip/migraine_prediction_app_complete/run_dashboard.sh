#!/bin/bash
cd dashboard
streamlit run streamlit_dashboard.py
